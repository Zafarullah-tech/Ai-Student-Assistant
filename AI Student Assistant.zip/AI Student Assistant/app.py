from flask import Flask, render_template, request, jsonify
import google.generativeai as genai
import os

app = Flask(__name__)

# 🔑 Gemini API Key
genai.configure(api_key="AIzaSyDMWI5SD3-RqMdZSmBZLpqrzWPIRi0vmF0")

model = genai.GenerativeModel("models/gemini-2.5-flash")

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.json
    user_message = data.get("message", "")

    if not user_message:
        
        return jsonify({"reply": "Please enter a question."})

    try:
        response = model.generate_content(
            f"You are a helpful study assistant. Answer clearly:\n{user_message}"
        )
        return jsonify({"reply": response.text})

    except Exception as e:
        return jsonify({"reply": f"Error: {str(e)}"})

if __name__ == "__main__":
    app.run(debug=True)